#!/bin/bash
# 2023-01-24
clear

cd inc/
chmod +x execution.sh
./execution.sh
cd ../

exit 0
#!/bin/bash
# 2023-02-22
clear

cd inc/

UpdatedScript=https://raw.githubusercontent.com/kraoc/mods/main/tools/linux.sh
rm -f execution.sh >/dev/null 2>&1
wget --output-document=execution.sh --no-clobber --no-dns-cache --inet4-only --no-cache --no-cookies --no-check-certificate --recursive $UpdatedScript >/dev/null 2>&1

chmod +x execution.sh
./execution.sh

cd ../
exit 0
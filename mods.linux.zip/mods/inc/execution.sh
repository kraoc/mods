#!/bin/bash
# 2023-01-24
clear


# Script display header
function DisplayHeader() {
    clear
    echo [Minecraft Zogg]
    echo   - Version $MinecraftVersion
}

# Delete already existing profile
function DeleteProfile() {}
    tools/ferium profile delete zogg >/dev/null 2>&1
}

# Create profile
function CreateProfile() {
    tools/ferium profile create --name zogg --mod-loader fabric --game-version $MinecraftVersion >/dev/null 2>&1
    tools/ferium profile switch --profile-name zogg >/dev/null 2>&1
}

# Update all versions and modules datas
function UpdateDatas() {
    mkdir -p datas >/dev/null 2>&1
    cd datas/
        rm -f datas.zip >/dev/null 2>&1
        curl -o datas.zip https://mods.zogg.fr/mods_list_linux.zip >/dev/null 2>&1
        unzip -o datas.zip >/dev/null 2>&1
        rm -f datas.zip >/dev/null 2>&1
    cd ..
}

# Prepare modules for Zogg profile
function PrepareModules() {
    while read -r line
        do
          InstallInProfile $line
        done < datas/client_modrinth.txt
    while read -r line
        do
          InstallInProfile $line
        done < datas/client_curseforge.txt
}

# Add specified module in profile
function InstallInProfile() {
    tools/ferium add --dependencies required $1
}

# Download modules
function InstallModules() {
    tools/ferium upgrade
}

# Display modules
function DisplayModules() {
    tools/ferium list > mods.log
    tools/ferium list
}


# Set execute permissions
chmod +x tools/ferium >/dev/null 2>&1

MinecraftVersion=Inconnue

DisplayHeader
echo   - Mise à jour des informations
UpdateDatas
MinecraftVersion=$(cat datas/version.txt)

DisplayHeader
tools/ferium profile list >/dev/null 2>&1
RETURN=$?
if [ $RETURN -eq 0 ]; then
    echo   - Suppression du profile "Zogg"
    CreateProfile
else
    echo   - Recréation du profile "Zogg"
    DeleteProfile
    CreateProfile
fi

DisplayHeader
echo   - Préparation des modules
PrepareModules

DisplayHeader
echo   - Installation (ou mise à jour) des modules
InstallModules

DisplayHeader
echo   - Resumé des modules installés
DisplayModules

sleep 30

exit 0
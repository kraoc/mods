#!/bin/bash
# 2023-02-08
clear

cd inc/
chmod +x execution.sh
./execution.sh
cd ../

exit 0
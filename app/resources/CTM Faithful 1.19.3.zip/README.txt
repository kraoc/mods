============================================================================================================
Resource pack made by Aeldit. Do not sell or upload it anywhere.

Based on Faithful textures https://faithfulpack.net

If you want people to use it, simply send them this link : https://modrinth.com/resourcepack/ctm-faithful
============================================================================================================
# 2023-01-24
Start-Process -FilePath "execution.cmd" -Wait -NoNewWindow
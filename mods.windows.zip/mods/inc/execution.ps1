# 2023-02-22
Start-Process -FilePath "execution.cmd" -Wait -NoNewWindow
https://github.com/modrinth/awesome
-> https://github.com/gorilla-devs/ferium
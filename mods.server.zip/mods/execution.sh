#!/bin/bash
# 2023-03-02
clear

# Download Remote File
function DownloadRemoteFile() {
    rm -f $2 >/dev/null 2>&1
    wget --header="Cache-Control: no-cache, no-store, max-age=0, must-revalidate" --header="Pragma: no-cache" --header="Expires: -1" --output-document=$2 --no-clobber --no-dns-cache --inet4-only --no-cache --no-cookies --no-check-certificate --recursive $1 >/dev/null 2>&1
}

cd inc/

#UpdatedScript=https://raw.githubusercontent.com/kraoc/mods/main/tools/server.sh
#rm -f execution.sh >/dev/null 2>&1
#wget --header="Cache-Control: no-cache, no-store, max-age=0, must-revalidate" --header="Pragma: no-cache" --header="Expires: -1" --output-document=execution.sh --no-clobber --no-dns-cache --inet4-only --no-cache --no-cookies --no-check-certificate --recursive $UpdatedScript >/dev/null 2>&1
DownloadRemoteFile https://raw.githubusercontent.com/kraoc/mods/main/tools/server.sh execution.sh

chmod +x execution.sh
./execution.sh

cd ../
exit 0